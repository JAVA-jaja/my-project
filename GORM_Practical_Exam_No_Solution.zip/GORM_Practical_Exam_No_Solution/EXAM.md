# โจทย์: ระบบจองห้องพักโรงแรม

เวลาแนะนำ: 60 นาที

## Class Diagram

```mermaid
classDiagram
    class Customer {
        +uint ID PK
        +string CustomerCode UK
        +string FullName
        +string Email UK
        +datetime CreatedAt
    }
    class Room {
        +uint ID PK
        +string RoomNumber UK
        +string RoomType
        +float64 PricePerNight
        +bool IsAvailable
    }
    class Reservation {
        +uint ID PK
        +string ReservationNo UK
        +uint CustomerID FK
        +uint RoomID FK
        +datetime CheckIn
        +datetime CheckOut
        +string Status
        +datetime CreatedAt
    }
    class Service {
        +uint ID PK
        +string Name UK
        +float64 Price
    }
    class ReservationService {
        +uint ReservationID PK, FK
        +uint ServiceID PK, FK
        +int Quantity
    }
    class Payment {
        +uint ID PK
        +uint ReservationID FK, UK
        +float64 Amount
        +string Method
        +datetime PaidAt nullable
    }

    Customer "1" --> "0..*" Reservation
    Room "1" --> "0..*" Reservation
    Reservation "1" --> "0..*" ReservationService
    Service "1" --> "0..*" ReservationService
    Reservation "1" --> "0..1" Payment
```

## Requirements

### Customer

- ใช้ตาราง `customers`
- `ID` เป็น unsigned integer และ Primary Key
- `CustomerCode` เป็น string ความยาวไม่เกิน 12, ห้ามเป็นค่าว่าง และห้ามซ้ำ
- `FullName` เป็น string ความยาวไม่เกิน 150 และห้ามเป็นค่าว่าง
- `Email` เป็น string ความยาวไม่เกิน 120, ห้ามเป็นค่าว่าง และห้ามซ้ำ
- `CreatedAt` เก็บเวลาและกำหนดค่าอัตโนมัติเมื่อสร้างข้อมูล
- ลูกค้าหนึ่งคนมีรายการจองได้หลายรายการ

### Room

- ใช้ตาราง `rooms`
- `ID` เป็น unsigned integer และ Primary Key
- `RoomNumber` เป็น string ความยาวไม่เกิน 10, ห้ามเป็นค่าว่าง และห้ามซ้ำ
- `RoomType` เป็น string ความยาวไม่เกิน 50 และห้ามเป็นค่าว่าง
- `PricePerNight` เป็น float64 และห้ามเป็นค่าว่าง
- `IsAvailable` เป็น bool และมีค่าเริ่มต้นเป็น true
- ห้องหนึ่งห้องมีรายการจองได้หลายรายการ

### Reservation

- ใช้ตาราง `reservations`
- `ID` เป็น unsigned integer และ Primary Key
- `ReservationNo` เป็น string ความยาวไม่เกิน 20, ห้ามเป็นค่าว่าง และห้ามซ้ำ
- เป็นฝั่งที่ถือ Foreign Key ของ Customer และ Room
- `CheckIn` และ `CheckOut` ใช้ `time.Time` และห้ามเป็นค่าว่าง
- `Status` เป็น string ความยาวไม่เกิน 20, ห้ามเป็นค่าว่าง และมีค่าเริ่มต้น `pending`
- `CreatedAt` กำหนดค่าอัตโนมัติเมื่อสร้างข้อมูล
- เมื่อลบ Customer หรือ Room ที่ยังมี Reservation ต้องไม่อนุญาตให้ลบ
- มีรายการบริการเสริมได้หลายรายการ และมี Payment ได้ไม่เกินหนึ่งรายการ

### Service

- ใช้ตาราง `services`
- `ID` เป็น unsigned integer และ Primary Key
- `Name` เป็น string ความยาวไม่เกิน 100, ห้ามเป็นค่าว่าง และห้ามซ้ำ
- `Price` เป็น float64 และห้ามเป็นค่าว่าง
- บริการหนึ่งชนิดอยู่ในหลายรายการจองได้

### ReservationService

- ใช้ตาราง `reservation_services`
- เป็นตารางกลางของ Reservation และ Service
- ใช้ Foreign Key ทั้งสองคอลัมน์รวมกันเป็น Composite Primary Key
- `Quantity` เป็น int, ห้ามเป็นค่าว่าง และมีค่าเริ่มต้นเป็น 1
- เมื่อลบ Reservation ให้ลบรายการบริการของการจองนั้นตามไปด้วย
- ห้ามลบ Service ถ้ายังมีรายการจองอ้างถึง

### Payment

- ใช้ตาราง `payments`
- `ID` เป็น unsigned integer และ Primary Key
- `ReservationID` เป็น Foreign Key, ห้ามเป็นค่าว่าง และห้ามซ้ำ เพื่อบังคับความสัมพันธ์ 1:1
- `Amount` เป็น float64 และห้ามเป็นค่าว่าง
- `Method` เป็น string ความยาวไม่เกิน 30 และห้ามเป็นค่าว่าง
- `PaidAt` ใช้ pointer ของ `time.Time` เพราะยังไม่มีเวลาชำระเมื่อยังไม่จ่ายเงิน
- เมื่อลบ Reservation ให้ลบ Payment ที่เกี่ยวข้องตามไปด้วย

