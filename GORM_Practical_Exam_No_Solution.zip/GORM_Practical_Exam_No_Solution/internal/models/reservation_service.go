package models

type ReservationService struct{}
