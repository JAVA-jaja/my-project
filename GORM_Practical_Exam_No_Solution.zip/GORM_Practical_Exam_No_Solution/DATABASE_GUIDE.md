# วิธีสร้างไฟล์ฐานข้อมูลและเปิดด้วย SQLite Viewer

## ชื่อไฟล์ฐานข้อมูล

โปรเจกต์นี้กำหนดให้สร้างไฟล์เพียงไฟล์เดียว:

```text
practical_exam.db
```

ไฟล์จะถูกสร้างที่โฟลเดอร์รากของโปรเจกต์ ซึ่งเป็นตำแหน่งเดียวกับ `go.mod`

## ขั้นตอนสร้างไฟล์ `.db`

1. เขียน Model ใน `internal/models/` ให้ครบ
2. เปิด Terminal ของ VS Code
3. ตรวจสอบว่า Terminal อยู่ในโฟลเดอร์เดียวกับ `go.mod`
4. รัน Test ก่อน:

```powershell
go test -v ./tests/... -count=1
```

5. เมื่อ Test แสดง `PASS` ให้รัน:

```powershell
go run ./cmd/database
```

6. ถ้าสำเร็จ Terminal จะแสดงข้อความว่าได้สร้าง `practical_exam.db` แล้ว

หาก Model ยังไม่สมบูรณ์ โปรแกรมอาจไม่สามารถสร้างตารางได้ ให้แก้ Model แล้วรันคำสั่งเดิมอีกครั้ง

## วิธีเปิดใน SQLite Viewer

1. เปิดโปรเจกต์นี้ด้วย Visual Studio Code
2. ติดตั้ง Extension ชื่อ `SQLite Viewer`
3. รัน `go run ./cmd/database` เพื่อสร้างฐานข้อมูล
4. กด Refresh ที่ Explorer ของ VS Code หากยังไม่เห็นไฟล์
5. คลิกไฟล์ `practical_exam.db`
6. ตรวจว่ามีตารางต่อไปนี้:

```text
customers
rooms
reservations
services
reservation_services
payments
```

7. เลือกแต่ละตารางเพื่อตรวจคอลัมน์ ชนิดข้อมูล Primary Key และข้อมูล
8. เปิดส่วน Structure หรือ Schema ของ SQLite Viewer เพื่อตรวจ Foreign Key, Unique Index และ Composite Primary Key

## เมื่อแก้ Model แล้ว Schema ไม่เปลี่ยน

ในระหว่างฝึก สามารถปิด SQLite Viewer แล้วลบ `practical_exam.db` จากนั้นรันใหม่:

```powershell
go run ./cmd/database
```

การลบฐานข้อมูลจะทำให้ข้อมูลเดิมทั้งหมดหาย จึงควรทำเฉพาะกับฐานข้อมูลสำหรับฝึกเท่านั้น

