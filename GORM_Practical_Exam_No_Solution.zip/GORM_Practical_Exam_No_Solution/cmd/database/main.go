package main

import (
	"fmt"
	"log"

	"gorm-practical-exam/internal/models"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

const databaseFile = "practical_exam.db"

func main() {
	db, err := gorm.Open(sqlite.Open(databaseFile), &gorm.Config{})
	if err != nil {
		log.Fatal(err)
	}

	if err := db.Exec("PRAGMA foreign_keys = ON").Error; err != nil {
		log.Fatal(err)
	}

	if err := db.AutoMigrate(
		&models.Customer{},
		&models.Room{},
		&models.Reservation{},
		&models.Service{},
		&models.ReservationService{},
		&models.Payment{},
	); err != nil {
		log.Fatal(err)
	}

	fmt.Printf("PASS: created %s successfully\n", databaseFile)
}
