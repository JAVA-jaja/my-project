$ErrorActionPreference = "Stop"

Write-Host "Running GORM practical exam tests..." -ForegroundColor Cyan
go test -v ./tests/... -count=1

if ($LASTEXITCODE -eq 0) {
    Write-Host "PASS: All model requirements are correct." -ForegroundColor Green
    exit 0
}

Write-Host "FAIL: Some model requirements are not correct. Read the test output above." -ForegroundColor Red
exit 1

