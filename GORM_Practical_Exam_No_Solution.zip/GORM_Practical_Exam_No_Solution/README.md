# Practical Exam - Hotel Reservation Models

ชุดข้อสอบจำลองการเขียน Go Model ด้วย GORM ไม่มีไฟล์เฉลย

## สิ่งที่ต้องทำ

อ่านโจทย์ใน `EXAM.md` แล้วเขียน Model ทั้งหมดในโฟลเดอร์ `internal/models/`

ไฟล์ Model เริ่มต้นมีเพียงชื่อ struct เท่านั้น นักศึกษาต้องกำหนด fields, data types, Primary Key, Foreign Key, relationships และ GORM tags ด้วยตนเอง

## ทดสอบคำตอบ

```powershell
go test -v ./tests/... -count=1
```

หรือรัน:

```powershell
.\check.ps1
```

ผลลัพธ์จะระบุ `PASS` เมื่อผ่าน และ `FAIL` พร้อมหัวข้อที่ยังไม่ถูกต้องเมื่อไม่ผ่าน

## สร้างและเปิดฐานข้อมูล

อ่านขั้นตอนทั้งหมดใน `DATABASE_GUIDE.md`

ชื่อฐานข้อมูลที่กำหนด: `practical_exam.db`

## กติกาชุดฝึก

- แก้ไขเฉพาะไฟล์ใน `internal/models/`
- ห้ามแก้ไขไฟล์ใน `tests/` เพื่อทำให้ Test ผ่าน
- ไม่มีเฉลยรวมอยู่ในโปรเจกต์
- แนะนำให้จับเวลา 60 นาที

