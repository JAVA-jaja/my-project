package tests

import (
	"testing"

	"gorm-practical-exam/internal/models"
)

func TestImportantConstraints(t *testing.T) {
	tests := []struct {
		model  any
		fields []string
	}{
		{&models.Customer{}, []string{"CustomerCode", "FullName", "Email"}},
		{&models.Room{}, []string{"RoomNumber", "RoomType", "PricePerNight"}},
		{&models.Reservation{}, []string{"ReservationNo", "CustomerID", "RoomID", "CheckIn", "CheckOut", "Status"}},
		{&models.Service{}, []string{"Name", "Price"}},
		{&models.ReservationService{}, []string{"Quantity"}},
		{&models.Payment{}, []string{"ReservationID", "Amount", "Method"}},
	}
	for _, tc := range tests {
		sch := parseSchema(t, tc.model)
		for _, name := range tc.fields {
			f := sch.LookUpField(name)
			if f == nil {
				t.Errorf("FAIL: %s is missing field %s", sch.Name, name)
				continue
			}
			if !f.NotNull {
				t.Errorf("FAIL: %s.%s must be NOT NULL", sch.Name, name)
			}
		}
	}
}
