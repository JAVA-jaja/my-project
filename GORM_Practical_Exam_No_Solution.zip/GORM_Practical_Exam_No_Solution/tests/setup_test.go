package tests

import (
	"reflect"
	"sync"
	"testing"

	"gorm.io/gorm/schema"
)

var schemaCache sync.Map

func parseSchema(t *testing.T, model any) *schema.Schema {
	t.Helper()
	sch, err := schema.Parse(model, &schemaCache, schema.NamingStrategy{})
	if err != nil {
		t.Fatalf("FAIL: cannot parse model %T: %v", model, err)
	}
	return sch
}

func requireField(t *testing.T, sch *schema.Schema, name string, expectedType reflect.Type) *schema.Field {
	t.Helper()
	f := sch.LookUpField(name)
	if f == nil {
		t.Fatalf("FAIL: %s is missing required field %s", sch.Name, name)
	}
	if f.FieldType != expectedType {
		t.Fatalf("FAIL: %s.%s has type %v; requirement expects %v", sch.Name, name, f.FieldType, expectedType)
	}
	return f
}

func requireTag(t *testing.T, f *schema.Field, tag string) {
	t.Helper()
	if _, ok := f.TagSettings[tag]; !ok {
		t.Errorf("FAIL: %s is missing required GORM setting %s", f.Name, tag)
	}
}
