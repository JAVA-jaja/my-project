package tests

import (
	"reflect"
	"testing"
	"time"

	"gorm-practical-exam/internal/models"
)

func TestReservationFieldsAndRelationships(t *testing.T) {
	sch := parseSchema(t, &models.Reservation{})
	id := requireField(t, sch, "ID", reflect.TypeOf(uint(0)))
	if !id.PrimaryKey {
		t.Error("FAIL: Reservation.ID must be a primary key")
	}
	for _, tc := range []struct {
		name string
		typ  reflect.Type
	}{
		{"ReservationNo", reflect.TypeOf("")}, {"CustomerID", reflect.TypeOf(uint(0))},
		{"RoomID", reflect.TypeOf(uint(0))}, {"CheckIn", reflect.TypeOf(time.Time{})},
		{"CheckOut", reflect.TypeOf(time.Time{})}, {"Status", reflect.TypeOf("")},
		{"CreatedAt", reflect.TypeOf(time.Time{})},
	} {
		requireField(t, sch, tc.name, tc.typ)
	}
	for _, name := range []string{"Customer", "Room", "ReservationServices", "Payment"} {
		if _, ok := sch.Relationships.Relations[name]; !ok {
			t.Errorf("FAIL: Reservation is missing relationship %s", name)
		}
	}
}
