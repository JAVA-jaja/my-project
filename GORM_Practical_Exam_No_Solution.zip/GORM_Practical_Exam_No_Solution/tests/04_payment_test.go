package tests

import (
	"reflect"
	"testing"
	"time"

	"gorm-practical-exam/internal/models"
)

func TestPaymentModel(t *testing.T) {
	sch := parseSchema(t, &models.Payment{})
	id := requireField(t, sch, "ID", reflect.TypeOf(uint(0)))
	if !id.PrimaryKey {
		t.Error("FAIL: Payment.ID must be a primary key")
	}
	reservationID := requireField(t, sch, "ReservationID", reflect.TypeOf(uint(0)))
	if !reservationID.Unique && reservationID.UniqueIndex == "" {
		t.Error("FAIL: Payment.ReservationID must enforce uniqueness for a one-to-one relationship")
	}
	requireField(t, sch, "Amount", reflect.TypeOf(float64(0)))
	requireField(t, sch, "Method", reflect.TypeOf(""))
	paidAt := requireField(t, sch, "PaidAt", reflect.TypeOf((*time.Time)(nil)))
	if paidAt.NotNull {
		t.Error("FAIL: Payment.PaidAt must allow NULL")
	}
	if _, ok := sch.Relationships.Relations["Reservation"]; !ok {
		t.Error("FAIL: Payment must declare its Reservation relationship")
	}
}
