package tests

import (
	"reflect"
	"testing"
	"time"

	"gorm-practical-exam/internal/models"
)

func TestCustomerModel(t *testing.T) {
	sch := parseSchema(t, &models.Customer{})
	if sch.Table != "customers" {
		t.Errorf("FAIL: Customer table is %q, expected customers", sch.Table)
	}
	id := requireField(t, sch, "ID", reflect.TypeOf(uint(0)))
	if !id.PrimaryKey {
		t.Error("FAIL: Customer.ID must be a primary key")
	}
	for _, tc := range []struct {
		name string
		typ  reflect.Type
	}{
		{"CustomerCode", reflect.TypeOf("")}, {"FullName", reflect.TypeOf("")},
		{"Email", reflect.TypeOf("")}, {"CreatedAt", reflect.TypeOf(time.Time{})},
	} {
		requireField(t, sch, tc.name, tc.typ)
	}
	if _, ok := sch.Relationships.Relations["Reservations"]; !ok {
		t.Error("FAIL: Customer must declare its Reservations relationship")
	}
}

func TestRoomModel(t *testing.T) {
	sch := parseSchema(t, &models.Room{})
	id := requireField(t, sch, "ID", reflect.TypeOf(uint(0)))
	if !id.PrimaryKey {
		t.Error("FAIL: Room.ID must be a primary key")
	}
	for _, tc := range []struct {
		name string
		typ  reflect.Type
	}{
		{"RoomNumber", reflect.TypeOf("")}, {"RoomType", reflect.TypeOf("")},
		{"PricePerNight", reflect.TypeOf(float64(0))}, {"IsAvailable", reflect.TypeOf(false)},
	} {
		requireField(t, sch, tc.name, tc.typ)
	}
	if _, ok := sch.Relationships.Relations["Reservations"]; !ok {
		t.Error("FAIL: Room must declare its Reservations relationship")
	}
}
