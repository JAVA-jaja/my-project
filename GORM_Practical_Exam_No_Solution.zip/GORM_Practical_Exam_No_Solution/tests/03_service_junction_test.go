package tests

import (
	"reflect"
	"testing"

	"gorm-practical-exam/internal/models"
)

func TestServiceModel(t *testing.T) {
	sch := parseSchema(t, &models.Service{})
	id := requireField(t, sch, "ID", reflect.TypeOf(uint(0)))
	if !id.PrimaryKey {
		t.Error("FAIL: Service.ID must be a primary key")
	}
	requireField(t, sch, "Name", reflect.TypeOf(""))
	requireField(t, sch, "Price", reflect.TypeOf(float64(0)))
	if _, ok := sch.Relationships.Relations["ReservationServices"]; !ok {
		t.Error("FAIL: Service must declare its ReservationServices relationship")
	}
}

func TestReservationServiceCompositePrimaryKey(t *testing.T) {
	sch := parseSchema(t, &models.ReservationService{})
	requireField(t, sch, "ReservationID", reflect.TypeOf(uint(0)))
	requireField(t, sch, "ServiceID", reflect.TypeOf(uint(0)))
	requireField(t, sch, "Quantity", reflect.TypeOf(int(0)))
	if len(sch.PrimaryFields) != 2 {
		t.Fatalf("FAIL: ReservationService must have exactly 2 primary-key fields; got %d", len(sch.PrimaryFields))
	}
	for _, name := range []string{"Reservation", "Service"} {
		if _, ok := sch.Relationships.Relations[name]; !ok {
			t.Errorf("FAIL: ReservationService is missing relationship %s", name)
		}
	}
}
