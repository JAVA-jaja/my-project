package models

import (
	"reflect"
	"sync"
	"testing"

	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
	"gorm.io/gorm/schema"
)

func parse(t *testing.T, value any) *schema.Schema {
	t.Helper()
	s, err := schema.Parse(value, &syncMap, schema.NamingStrategy{})
	if err != nil {
		t.Fatal(err)
	}
	return s
}

var syncMap = sync.Map{}

func field(t *testing.T, s *schema.Schema, name string) *schema.Field {
	t.Helper()
	f := s.LookUpField(name)
	if f == nil {
		t.Fatalf("%s: missing field %s", s.Name, name)
	}
	return f
}

func requireType(t *testing.T, f *schema.Field, typ reflect.Type) {
	t.Helper()
	if f.FieldType != typ {
		t.Errorf("%s: got type %v, want %v", f.Name, f.FieldType, typ)
	}
}

func TestRequiredFieldsAndKeys(t *testing.T) {
	student := parse(t, &Student{})
	requireType(t, field(t, student, "ID"), reflect.TypeOf(uint(0)))
	if !field(t, student, "ID").PrimaryKey {
		t.Error("Student.ID must be primary key")
	}
	for _, name := range []string{"Code", "FullName", "Email", "CreatedAt", "Registrations"} {
		field(t, student, name)
	}

	instructor := parse(t, &Instructor{})
	if !field(t, instructor, "ID").PrimaryKey {
		t.Error("Instructor.ID must be primary key")
	}
	for _, name := range []string{"EmployeeNo", "FullName", "Email", "Courses"} {
		field(t, instructor, name)
	}

	course := parse(t, &Course{})
	if !field(t, course, "ID").PrimaryKey {
		t.Error("Course.ID must be primary key")
	}
	requireType(t, field(t, course, "Credits"), reflect.TypeOf(uint8(0)))
	for _, name := range []string{"Code", "Title", "InstructorID", "Instructor", "Registrations"} {
		field(t, course, name)
	}

	registration := parse(t, &Registration{})
	for _, name := range []string{"StudentID", "CourseID", "Student", "Course", "RegisteredAt", "Status"} {
		field(t, registration, name)
	}
	if len(registration.PrimaryFields) != 2 {
		t.Errorf("Registration must have 2 primary-key fields, got %d", len(registration.PrimaryFields))
	}
}

func TestMigrationConstraintsAndSeed(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file::memory:?cache=shared"), &gorm.Config{})
	if err != nil {
		t.Fatal(err)
	}
	if err := db.Exec("PRAGMA foreign_keys = ON").Error; err != nil {
		t.Fatal(err)
	}
	if err := db.AutoMigrate(&Student{}, &Instructor{}, &Course{}, &Registration{}); err != nil {
		t.Fatal(err)
	}

	for _, table := range []string{"students", "instructors", "courses", "registrations"} {
		if !db.Migrator().HasTable(table) {
			t.Errorf("missing table %s", table)
		}
	}
	for _, tc := range []struct {
		model any
		field string
	}{
		{&Student{}, "Code"}, {&Student{}, "Email"}, {&Instructor{}, "EmployeeNo"},
		{&Instructor{}, "Email"}, {&Course{}, "Code"},
	} {
		if !db.Migrator().HasIndex(tc.model, tc.field) {
			t.Errorf("%T.%s must have an index", tc.model, tc.field)
		}
	}

	if err := Seed(db); err != nil {
		t.Fatalf("Seed: %v", err)
	}
	for name, model := range map[string]any{"students": &Student{}, "instructors": &Instructor{}, "courses": &Course{}, "registrations": &Registration{}} {
		var count int64
		if err := db.Model(model).Count(&count).Error; err != nil {
			t.Fatal(err)
		}
		if count == 0 {
			t.Errorf("Seed must insert data into %s", name)
		}
	}
}
