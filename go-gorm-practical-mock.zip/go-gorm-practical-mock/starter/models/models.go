package models

import "gorm.io/gorm"

// TODO: เติมชนิดข้อมูล constants, fields, relationships และ GORM tags
// ให้ตรงกับ EXAM.md ห้ามเปลี่ยนชื่อ struct หรือชื่อ field ที่โจทย์กำหนด

type RegistrationStatus string

type Student struct{}

type Instructor struct{}

type Course struct{}

type Registration struct{}

// Seed จะถูกใช้หลัง migration เพื่อให้ตรวจฐานข้อมูลด้วย SQLite Viewer ได้
// TODO: หลังสร้าง Model ครบแล้ว ให้สร้างข้อมูลตัวอย่างอย่างน้อย 1 แถวต่อ table
func Seed(db *gorm.DB) error {
	return nil
}
