package main

import (
	"log"

	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
	"practical-exam/models"
)

func main() {
	db, err := gorm.Open(sqlite.Open("exam.db"), &gorm.Config{})
	if err != nil {
		log.Fatal(err)
	}

	if err := db.AutoMigrate(
		&models.Student{},
		&models.Instructor{},
		&models.Course{},
		&models.Registration{},
	); err != nil {
		log.Fatal(err)
	}

	if err := models.Seed(db); err != nil {
		log.Fatal(err)
	}

	log.Println("created exam.db; open it with SQLite Viewer")
}
