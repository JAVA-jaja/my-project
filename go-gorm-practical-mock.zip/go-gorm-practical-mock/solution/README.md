# เฉลยอ้างอิง

รันคำสั่งต่อไปนี้เพื่อตรวจ migration และสร้างฐานข้อมูล

```powershell
go mod tidy
go run .
```

จากนั้นเปิด `exam.db` ด้วย SQLite Viewer เปรียบเทียบกับ Requirements ใน `../EXAM.md`

