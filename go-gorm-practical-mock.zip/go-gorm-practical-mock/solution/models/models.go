package models

import (
	"time"

	"gorm.io/gorm"
)

type RegistrationStatus string

const (
	StatusEnrolled  RegistrationStatus = "enrolled"
	StatusDropped   RegistrationStatus = "dropped"
	StatusCompleted RegistrationStatus = "completed"
)

type Student struct {
	ID            uint           `gorm:"primaryKey"`
	Code          string         `gorm:"size:10;not null;uniqueIndex"`
	FullName      string         `gorm:"size:120;not null"`
	Email         string         `gorm:"size:120;not null;uniqueIndex"`
	CreatedAt     time.Time      `gorm:"autoCreateTime"`
	Registrations []Registration `gorm:"foreignKey:StudentID;constraint:OnUpdate:CASCADE,OnDelete:CASCADE"`
}

type Instructor struct {
	ID         uint     `gorm:"primaryKey"`
	EmployeeNo string   `gorm:"size:10;not null;uniqueIndex"`
	FullName   string   `gorm:"size:120;not null"`
	Email      string   `gorm:"size:120;not null;uniqueIndex"`
	Courses    []Course `gorm:"foreignKey:InstructorID;constraint:OnUpdate:CASCADE,OnDelete:RESTRICT"`
}

type Course struct {
	ID            uint           `gorm:"primaryKey"`
	Code          string         `gorm:"size:10;not null;uniqueIndex"`
	Title         string         `gorm:"size:150;not null"`
	Credits       uint8          `gorm:"not null;check:credits_between_1_and_6,credits >= 1 AND credits <= 6"`
	InstructorID  uint           `gorm:"not null;index"`
	Instructor    Instructor     `gorm:"foreignKey:InstructorID;references:ID"`
	Registrations []Registration `gorm:"foreignKey:CourseID;constraint:OnUpdate:CASCADE,OnDelete:CASCADE"`
}

type Registration struct {
	StudentID    uint               `gorm:"primaryKey"`
	CourseID     uint               `gorm:"primaryKey"`
	Student      Student            `gorm:"foreignKey:StudentID;references:ID"`
	Course       Course             `gorm:"foreignKey:CourseID;references:ID"`
	RegisteredAt time.Time          `gorm:"autoCreateTime"`
	Status       RegistrationStatus `gorm:"type:text;not null;default:enrolled;check:status_valid,status IN ('enrolled','dropped','completed')"`
}

func Seed(db *gorm.DB) error {
	return db.Transaction(func(tx *gorm.DB) error {
		instructor := Instructor{EmployeeNo: "T0001", FullName: "Dr. Ada Lovelace", Email: "ada@example.edu"}
		if err := tx.FirstOrCreate(&instructor, Instructor{EmployeeNo: instructor.EmployeeNo}).Error; err != nil {
			return err
		}

		student := Student{Code: "S6500001", FullName: "Anan Student", Email: "anan@example.edu"}
		if err := tx.FirstOrCreate(&student, Student{Code: student.Code}).Error; err != nil {
			return err
		}

		course := Course{Code: "CS101", Title: "Programming Fundamentals", Credits: 3, InstructorID: instructor.ID}
		if err := tx.FirstOrCreate(&course, Course{Code: course.Code}).Error; err != nil {
			return err
		}

		registration := Registration{StudentID: student.ID, CourseID: course.ID, Status: StatusEnrolled}
		return tx.FirstOrCreate(&registration, Registration{StudentID: student.ID, CourseID: course.ID}).Error
	})
}
