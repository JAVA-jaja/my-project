# ข้อสอบจำลอง: University Course Registration

เวลา 60 นาที | คะแนนเต็ม 100 คะแนน

## ขอบเขตงาน

แก้ไขเฉพาะไฟล์ `starter/models/models.go` เพื่อสร้าง Go Model ด้วย GORM ให้ตรงตาม Class Diagram และ Requirements ห้ามแก้ test เพื่อทำให้ผลตรวจผ่าน

## Class Diagram

```mermaid
classDiagram
    class Student {
      +uint ID PK
      +string Code UK
      +string FullName
      +string Email UK
      +datetime CreatedAt
    }
    class Instructor {
      +uint ID PK
      +string EmployeeNo UK
      +string FullName
      +string Email UK
    }
    class Course {
      +uint ID PK
      +string Code UK
      +string Title
      +uint8 Credits
      +uint InstructorID FK
    }
    class Registration {
      +uint StudentID PK, FK
      +uint CourseID PK, FK
      +datetime RegisteredAt
      +string Status
    }

    Instructor "1" --> "0..*" Course : teaches
    Student "1" --> "0..*" Registration
    Course "1" --> "0..*" Registration
```

## Requirements

### Student

- `ID` เป็น `uint`, Primary Key
- `Code` เป็น `string` ขนาดไม่เกิน 10, ห้ามว่าง, ไม่ซ้ำ
- `FullName` เป็น `string` ขนาดไม่เกิน 120, ห้ามว่าง
- `Email` เป็น `string` ขนาดไม่เกิน 120, ห้ามว่าง, ไม่ซ้ำ
- `CreatedAt` เป็น `time.Time` และให้ GORM ใส่เวลาเมื่อสร้าง
- มีความสัมพันธ์ไปยัง `[]Registration`

### Instructor

- `ID` เป็น `uint`, Primary Key
- `EmployeeNo` เป็น `string` ขนาดไม่เกิน 10, ห้ามว่าง, ไม่ซ้ำ
- `FullName` เป็น `string` ขนาดไม่เกิน 120, ห้ามว่าง
- `Email` เป็น `string` ขนาดไม่เกิน 120, ห้ามว่าง, ไม่ซ้ำ
- มีความสัมพันธ์แบบ 1:N ไปยัง `[]Course`

### Course

- `ID` เป็น `uint`, Primary Key
- `Code` เป็น `string` ขนาดไม่เกิน 10, ห้ามว่าง, ไม่ซ้ำ
- `Title` เป็น `string` ขนาดไม่เกิน 150, ห้ามว่าง
- `Credits` เป็น `uint8`, ห้ามว่าง และต้องอยู่ระหว่าง 1 ถึง 6
- `InstructorID` เป็น `uint`, Foreign Key, ห้ามว่าง และสร้าง index
- มี field `Instructor` เพื่อประกาศความสัมพันธ์
- เมื่อลบ Instructor ที่ยังมี Course ให้อยู่ ต้องถูกปฏิเสธ (`RESTRICT`)
- เมื่อแก้ Primary Key ของ Instructor ให้ Foreign Key เปลี่ยนตาม (`CASCADE`)
- มีความสัมพันธ์ไปยัง `[]Registration`

### Registration

- เป็น associative entity ระหว่าง Student และ Course
- `StudentID` และ `CourseID` รวมกันเป็น Composite Primary Key และเป็น Foreign Key
- มี field `Student` และ `Course` เพื่อประกาศความสัมพันธ์
- เมื่อลบ Student หรือ Course ให้ลบ Registration ที่เกี่ยวข้อง (`CASCADE`)
- `RegisteredAt` เป็น `time.Time` และให้ GORM ใส่เวลาเมื่อสร้าง
- `Status` ใช้ชนิด `RegistrationStatus`, ห้ามว่าง, ค่าเริ่มต้นเป็น `enrolled`
- Status ที่ยอมรับ: `enrolled`, `dropped`, `completed`
- ประกาศ constants `StatusEnrolled`, `StatusDropped`, `StatusCompleted`

## สิ่งที่ต้องเห็นใน SQLite Viewer

- ตาราง `students`, `instructors`, `courses`, `registrations`
- `registrations` มี Primary Key 2 คอลัมน์
- มี Foreign Key ครบ 3 จุด
- คอลัมน์ที่กำหนด unique ต้องมี unique index
- หลังรันโปรแกรมมีข้อมูลตัวอย่างอย่างน้อยหนึ่งแถวในแต่ละตาราง
